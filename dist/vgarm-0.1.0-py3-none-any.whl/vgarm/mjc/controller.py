from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Optional

import mujoco
import numpy as np

from .robots import RobotSpec


@dataclass(frozen=True)
class TargetOffset:
    dx: float
    dy: float


_TARGET_OFFSETS: dict[str, TargetOffset] = {
    "左边": TargetOffset(dx=0.0, dy=0.15),
    "右边": TargetOffset(dx=0.0, dy=-0.15),
    "前面": TargetOffset(dx=0.10, dy=0.0),
    "后面": TargetOffset(dx=-0.10, dy=0.0),
    "中间": TargetOffset(dx=0.0, dy=0.0),
}


def _site_id(model: mujoco.MjModel, name: str) -> int:
    sid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, name)
    if sid < 0:
        raise KeyError(f"missing site: {name}")
    return sid


def _eq_id(model: mujoco.MjModel, name: str) -> int:
    eid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_EQUALITY, name)
    if eid < 0:
        raise KeyError(f"missing equality: {name}")
    return eid


def _actuated_qpos_and_dof(model: mujoco.MjModel) -> list[tuple[int, int]]:
    pairs: list[tuple[int, int]] = []
    for act_id in range(model.nu):
        jnt_id = int(model.actuator_trnid[act_id, 0])
        if jnt_id < 0:
            continue
        qpos_adr = int(model.jnt_qposadr[jnt_id])
        dof_adr = int(model.jnt_dofadr[jnt_id])
        pairs.append((qpos_adr, dof_adr))
    return pairs


class PickPlaceExecutor:
    def __init__(
        self,
        model: mujoco.MjModel,
        data: mujoco.MjData,
        robot: RobotSpec,
        object_names: Iterable[str],
        sync: Callable[[], None] | None = None,
    ):
        self.model = model
        self.data = data
        self.robot = robot
        self.attachment_site = _site_id(model, robot.attachment_site_name)
        self.eq_for_object = {name: _eq_id(model, f"attach_{name}") for name in object_names}
        self._act_map = _actuated_qpos_and_dof(model)
        self._sync = sync

    def step(self, n: int = 1) -> None:
        for _ in range(n):
            mujoco.mj_step(self.model, self.data)
            if self._sync is not None:
                self._sync()

    def move_attachment_to(self, target_xyz: np.ndarray, tol: float = 0.003, alpha: float = 0.6, iters: int = 2000) -> float:
        jacp = np.zeros((3, self.model.nv))
        for _ in range(iters):
            mujoco.mj_forward(self.model, self.data)
            mujoco.mj_jacSite(self.model, self.data, jacp, None, self.attachment_site)
            err = target_xyz - self.data.site_xpos[self.attachment_site]
            if float(np.linalg.norm(err)) < tol:
                return float(np.linalg.norm(err))
            a = jacp @ jacp.T + 1e-6 * np.eye(3)
            dqvel = jacp.T @ np.linalg.solve(a, err)
            qpos_next = self.data.qpos.copy()
            for qpos_adr, dof_adr in self._act_map:
                qpos_next[qpos_adr] = qpos_next[qpos_adr] + alpha * float(dqvel[dof_adr])
            for act_id, (qpos_adr, _) in enumerate(self._act_map):
                self.data.ctrl[act_id] = qpos_next[qpos_adr]
            mujoco.mj_step(self.model, self.data)
            if self._sync is not None:
                self._sync()
        mujoco.mj_forward(self.model, self.data)
        err = target_xyz - self.data.site_xpos[self.attachment_site]
        return float(np.linalg.norm(err))

    def pick_and_place(self, object_name: str, target_xy: tuple[float, float], base_h: float = 0.02) -> None:
        grab_site_name = f"{object_name}_grab"
        grab_site = _site_id(self.model, grab_site_name)
        eq_id = self.eq_for_object[object_name]

        mujoco.mj_forward(self.model, self.data)
        grasp = self.data.site_xpos[grab_site].copy()

        above = grasp.copy()
        above[2] += 0.12
        self.move_attachment_to(above, tol=0.004, alpha=0.7)

        down = grasp.copy()
        down[2] -= 0.01
        self.move_attachment_to(down, tol=0.003, alpha=0.6)

        self.data.eq_active[eq_id] = 1
        mujoco.mj_forward(self.model, self.data)

        lift = down.copy()
        lift[2] += 0.18
        self.move_attachment_to(lift, tol=0.005, alpha=0.7)

        place_above = np.array([target_xy[0], target_xy[1], base_h + 0.12], dtype=float)
        self.move_attachment_to(place_above, tol=0.006, alpha=0.7)

        place_down = np.array([target_xy[0], target_xy[1], base_h + 0.01], dtype=float)
        self.move_attachment_to(place_down, tol=0.004, alpha=0.6)

        self.data.eq_active[eq_id] = 0
        mujoco.mj_forward(self.model, self.data)

        retreat = place_down.copy()
        retreat[2] += 0.18
        self.move_attachment_to(retreat, tol=0.006, alpha=0.7)

    def resolve_target_xy(self, keyword: str, anchor_xy: tuple[float, float] = (0.55, 0.0)) -> tuple[float, float]:
        off = _TARGET_OFFSETS.get(keyword, TargetOffset(0.0, 0.0))
        return (anchor_xy[0] + off.dx, anchor_xy[1] + off.dy)

    def body_xy(self, body_name: str) -> tuple[float, float]:
        bid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, body_name)
        if bid < 0:
            raise KeyError(body_name)
        mujoco.mj_forward(self.model, self.data)
        p = self.data.xpos[bid]
        return (float(p[0]), float(p[1]))

    def lift_object(self, object_name: str, base_h: float = 0.02) -> None:
        xy = self.body_xy(object_name)
        self.pick_and_place(object_name, xy, base_h=base_h)

    def move_next_to(self, object_name: str, ref_object: str, direction: str, base_h: float = 0.02) -> None:
        ref_xy = self.body_xy(ref_object)
        target = self.resolve_target_xy(direction, anchor_xy=ref_xy)
        self.pick_and_place(object_name, target, base_h=base_h)

    def swap_objects(self, a: str, b: str, base_h: float = 0.02, stage_xy: Optional[tuple[float, float]] = None) -> None:
        a_xy = self.body_xy(a)
        b_xy = self.body_xy(b)
        if stage_xy is None:
            stage_xy = (0.55, 0.18)
        self.pick_and_place(a, stage_xy, base_h=base_h)
        self.pick_and_place(b, a_xy, base_h=base_h)
        self.pick_and_place(a, b_xy, base_h=base_h)
