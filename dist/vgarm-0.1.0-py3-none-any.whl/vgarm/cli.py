from __future__ import annotations

import argparse
from pathlib import Path

import mujoco

from vgarm.mjc import PickPlaceExecutor, available_robots, build_scene_xml
from vgarm.nlu import parse_cn
from vgarm.reconstruction import reconstruct_scene
from vgarm.reconstruction.types import SimObject


def _infer_color(rgba: tuple[float, float, float, float]) -> str | None:
    r, g, b, _ = rgba
    if r > 0.65 and g < 0.55 and b < 0.55:
        return "red"
    if r > 0.65 and g > 0.65 and b < 0.55:
        return "yellow"
    if b > 0.65 and r < 0.6:
        return "blue"
    if g > 0.65 and r < 0.6:
        return "green"
    return None


def _select_object(objects: list[SimObject], color: str | None, category: str | None) -> SimObject:
    candidates = objects
    if category is not None:
        candidates = [o for o in candidates if o.category == category]
    if color is not None:
        candidates_color = [o for o in candidates if _infer_color(o.rgba) == color]
        if candidates_color:
            candidates = candidates_color
        else:
            candidates = [o for o in candidates if color in o.name.lower()]
    if not candidates:
        raise ValueError("no matching object in scene")
    return candidates[0]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="vgarm")
    ap.add_argument("--robot", default="franka_fr3", help="franka_fr3 | franka_panda | ur5e | kinova_gen3")
    ap.add_argument("--image", default=None, help="可选：输入环境照片路径（当前未启用视觉模型）")
    ap.add_argument("--scene", default=None, help="场景JSON路径（MVP使用）")
    ap.add_argument("--cmd", required=True, help="中文指令，例如：把红色方块移到左边")
    ap.add_argument("--no-viewer", action="store_true", help="不启动图形窗口，执行后直接退出")
    args = ap.parse_args(argv)

    robots = available_robots()
    if args.robot not in robots:
        raise SystemExit(f"unknown robot: {args.robot}. available: {', '.join(sorted(robots))}")
    robot = robots[args.robot]

    if args.scene is not None:
        scene_path = str(Path(args.scene))
        layout = reconstruct_scene(scene_json_path=scene_path)
    else:
        layout = reconstruct_scene(image_path=args.image)

    robot_dir = Path(robot.include_xml_path).resolve().parent
    built = build_scene_xml(layout, robot, xml_base_dir=robot_dir)
    xml_path = robot_dir / f"_vgarm_scene_{robot.robot_id}.xml"
    xml_path.write_text(built.xml_text, encoding="utf-8")
    model = mujoco.MjModel.from_xml_path(str(xml_path))
    data = mujoco.MjData(model)

    intent = parse_cn(args.cmd)
    obj = None
    if intent.object_color is not None or intent.object_category is not None:
        obj = _select_object(layout.objects, intent.object_color, intent.object_category)
    anchor_xy = (0.55, 0.0)

    if args.no_viewer:
        execu = PickPlaceExecutor(model, data, robot, built.object_names, sync=None)
        if intent.kind == "move_to_dir":
            target_xy = execu.resolve_target_xy(intent.target_keyword or "中间", anchor_xy=anchor_xy)
            execu.pick_and_place(obj.name, target_xy=target_xy, base_h=0.02)
        elif intent.kind == "lift":
            execu.lift_object(obj.name, base_h=0.02)
        elif intent.kind == "move_next_to_object":
            ref = _select_object(layout.objects, intent.ref_color, None)
            execu.move_next_to(obj.name, ref.name, intent.target_keyword or "左边", base_h=0.02)
        elif intent.kind == "swap":
            a = _select_object(layout.objects, intent.object_color, None)
            b = _select_object(layout.objects, intent.ref_color, None)
            execu.swap_objects(a.name, b.name, base_h=0.02)
        elif intent.kind == "place_to_center":
            execu.pick_and_place(obj.name, anchor_xy, base_h=0.02)
        for _ in range(200):
            mujoco.mj_step(model, data)
        return 0

    try:
        from mujoco import viewer

        with viewer.launch_passive(model, data) as v:
            execu = PickPlaceExecutor(model, data, robot, built.object_names, sync=v.sync)
            if intent.kind == "move_to_dir":
                target_xy = execu.resolve_target_xy(intent.target_keyword or "中间", anchor_xy=anchor_xy)
                execu.pick_and_place(obj.name, target_xy=target_xy, base_h=0.02)
            elif intent.kind == "lift":
                execu.lift_object(obj.name, base_h=0.02)
            elif intent.kind == "move_next_to_object":
                ref = _select_object(layout.objects, intent.ref_color, None)
                execu.move_next_to(obj.name, ref.name, intent.target_keyword or "左边", base_h=0.02)
            elif intent.kind == "swap":
                a = _select_object(layout.objects, intent.object_color, None)
                b = _select_object(layout.objects, intent.ref_color, None)
                execu.swap_objects(a.name, b.name, base_h=0.02)
            elif intent.kind == "place_to_center":
                execu.pick_and_place(obj.name, anchor_xy, base_h=0.02)
            while v.is_running():
                mujoco.mj_step(model, data)
                v.sync()
        return 0
    except Exception:
        execu = PickPlaceExecutor(model, data, robot, built.object_names, sync=None)
        if intent.kind == "move_to_dir":
            target_xy = execu.resolve_target_xy(intent.target_keyword or "中间", anchor_xy=anchor_xy)
            execu.pick_and_place(obj.name, target_xy=target_xy, base_h=0.02)
        elif intent.kind == "lift":
            execu.lift_object(obj.name, base_h=0.02)
        elif intent.kind == "move_next_to_object":
            ref = _select_object(layout.objects, intent.ref_color, None)
            execu.move_next_to(obj.name, ref.name, intent.target_keyword or "左边", base_h=0.02)
        elif intent.kind == "swap":
            a = _select_object(layout.objects, intent.object_color, None)
            b = _select_object(layout.objects, intent.ref_color, None)
            execu.swap_objects(a.name, b.name, base_h=0.02)
        elif intent.kind == "place_to_center":
            execu.pick_and_place(obj.name, anchor_xy, base_h=0.02)
        for _ in range(1000):
            mujoco.mj_step(model, data)
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
